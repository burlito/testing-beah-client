#!/bin/bash

#
#  THIS IS NOT ACTUALL INSTALL SCRIPT THIS EXIST ONLY FOR PURPOSE EASIER DEVELOPMENT
#

if [ `id -u` -ne 0 ]; then
	echo -e "\e[31m"
	cat << EOF
#      WARNING
#
# You're not running this script as root. It probably won't work
#
# Just in case, I'm turning on set -x so you can debug it easier
#
#
EOF
	echo -e "\e[0m"
set -x
fi

# remove existing
rm -rf /usr/libexec/rhts-amanduch/
rm -rf /usr/share/rhts-amanduch/
rm -rf /etc/sysconfig/testing-beak.conf

if [ "x$1" ==  "x-u" ]; then
	echo "I guess I uninstalled this lib"
	exit 0
fi

# and install new
mkdir /usr/libexec/rhts-amanduch/
ln -s `pwd`/libexec/* /usr/libexec/rhts-amanduch/
mkdir /usr/share/rhts-amanduch/
ln -s `pwd`/lib/ /usr/share/rhts-amanduch/
ln -s `pwd`/etc/testing-beak.conf /etc/sysconfig/testing-beak.conf
echo -e "\e[32m"
cat << EOF
#
# WARNING. This is highly experimental script and there is no warranty with it.
# Be aware that this can destroy your computer, eat your cat, kill family, or even bring some back to life
# If you prefer stabler things, you may wait few weeks, Until I create RPM and fix bugs here
# If you want you can still call ./install -u and it will uninstall this before any harm was done.
#

#
# To make this working you need to add following line to
# /usr/share/rhts/lib/rhts-make.include or to your project Makefile:
-include /usr/share/rhts-amanduch/lib/rhts-make-amanduch.include

#
# to uninstall just run this script with -u argument
#
EOF
echo -e "\e[0m"
